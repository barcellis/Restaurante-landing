import { Header } from "@/components/restaurant/Header";
import { Hero } from "@/components/restaurant/Hero";
import { StorySection } from "@/components/restaurant/StorySection";
import { FeaturedDishes } from "@/components/restaurant/FeaturedDishes";
import { ExperienceSection } from "@/components/restaurant/ExperienceSection";
import { MenuSection } from "@/components/restaurant/MenuSection";
import { Gallery } from "@/components/restaurant/Gallery";
import { Testimonials } from "@/components/restaurant/Testimonials";
import { ReservationCTA } from "@/components/restaurant/ReservationCTA";
import { LocationSection } from "@/components/restaurant/LocationSection";
import { FinalCTA } from "@/components/restaurant/FinalCTA";
import { Footer } from "@/components/restaurant/Footer";

export default function Home() {
  return (
    <>
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-50 focus:bg-gold focus:text-ink focus:px-4 focus:py-2 focus:rounded-sm"
      >
        Pular para o conteúdo
      </a>

      <Header />

      <main id="main-content">
        <Hero />
        <StorySection />
        <FeaturedDishes />
        <ExperienceSection />
        <MenuSection />
        <Gallery />
        <Testimonials />
        <ReservationCTA />
        <LocationSection />
      </main>

      <FinalCTA />
      <Footer />
    </>
  );
}
