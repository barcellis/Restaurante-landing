import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Fraunces, Work_Sans } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-fraunces",
  display: "swap",
});

const workSans = Work_Sans({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600"],
  variable: "--font-work-sans",
  display: "swap",
});

export const metadata: Metadata = {
  title: "SAVORÉ — Sabores que transformam momentos",
  description:
    "Restaurante contemporâneo com cardápio autoral, ambiente intimista e experiência gastronômica completa. Reserve sua mesa.",
  openGraph: {
    title: "SAVORÉ — Sabores que transformam momentos",
    description:
      "Restaurante contemporâneo com cardápio autoral, ambiente intimista e experiência gastronômica completa.",
    type: "website",
    locale: "pt_BR",
    // SUBSTITUIR: adicionar images: ["/images/restaurant/hero.jpg"] quando a foto real existir
  },
};

export default function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <html lang="pt-BR" className={`${fraunces.variable} ${workSans.variable}`}>
      <body className="font-body bg-ink">{children}</body>
    </html>
  );
}
