/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    // Todas as imagens do projeto (incluindo os placeholders) são locais,
    // servidas de /public/images/restaurant. Se futuramente um CDN de
    // imagens for usado (Cloudinary, Supabase Storage etc.), adicione o
    // domínio em `remotePatterns` abaixo.
    remotePatterns: [],
    formats: ["image/avif", "image/webp"],
  },
};

export default nextConfig;
