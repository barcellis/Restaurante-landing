import type { Config } from "tailwindcss";

/**
 * Tokens de design centralizados aqui — cores, tipografia, etc.
 * Para alterar a identidade visual do SAVORÉ, edite apenas este arquivo.
 */
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: "#0c0a09",
          soft: "#1c1917",
        },
        paper: {
          DEFAULT: "#fafaf9",
          alt: "#f5f5f4",
        },
        gold: {
          DEFAULT: "#fbbf24",
          soft: "#fcd34d",
          deep: "#d97706",
        },
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "serif"],
        body: ["var(--font-work-sans)", "sans-serif"],
      },
    },
  },
  plugins: [],
};

export default config;
