"use client";

import { useEffect, useRef, useState } from "react";

/**
 * Detecta quando um elemento entra na viewport, para animações de
 * "reveal on scroll". Usado por <Reveal> (components/restaurant/Reveal.tsx).
 */
export function useInView(threshold = 0.15) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          observer.unobserve(node);
        }
      },
      { threshold, rootMargin: "0px 0px -60px 0px" }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [threshold]);

  return { ref, inView } as const;
}
