"use client";

import { useEffect, useState } from "react";

/**
 * Retorna true quando a página foi rolada além de `offset` pixels.
 * Usado pelo <Header> para escurecer o fundo ao rolar a página.
 */
export function useScrolled(offset = 40) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > offset);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [offset]);

  return scrolled;
}
