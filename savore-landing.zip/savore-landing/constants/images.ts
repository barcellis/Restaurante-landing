/**
 * Centraliza todos os caminhos de imagem do projeto.
 *
 * PRODUÇÃO: substitua os arquivos dentro de public/images/restaurant/
 * mantendo exatamente estes nomes — nenhum componente precisa ser alterado.
 * Até lá, <Photo> (components/restaurant/Photo.tsx) exibe um placeholder
 * elegante automaticamente para qualquer caminho que ainda não exista.
 */
export const images = {
  hero: "/images/restaurant/hero.jpg",
  story: "/images/restaurant/story.jpg",
  reservation: "/images/restaurant/reserva-bg.jpg",
  finalCta: "/images/restaurant/cta-final.jpg",
  dishes: {
    dish01: "/images/restaurant/dish-01.jpg",
    dish02: "/images/restaurant/dish-02.jpg",
    dish03: "/images/restaurant/dish-03.jpg",
    dish04: "/images/restaurant/dish-04.jpg",
  },
  experience: {
    salao: "/images/restaurant/ambiente-salao.jpg",
    detalhe: "/images/restaurant/ambiente-detalhe.jpg",
    jantar: "/images/restaurant/ambiente-pessoas.jpg",
    prato: "/images/restaurant/ambiente-prato.jpg",
  },
  gallery: {
    g1: "/images/restaurant/galeria-01.jpg",
    g2: "/images/restaurant/galeria-02.jpg",
    g3: "/images/restaurant/galeria-03.jpg",
    g4: "/images/restaurant/galeria-04.jpg",
    g5: "/images/restaurant/galeria-05.jpg",
    g6: "/images/restaurant/galeria-06.jpg",
    g7: "/images/restaurant/galeria-07.jpg",
    g8: "/images/restaurant/galeria-08.jpg",
  },
} as const;
