export interface RestaurantHours {
  days: string;
  time: string;
}

export interface RestaurantInfo {
  name: string;
  slogan: string;
  since: string;
  address: string;
  phone: string;
  phoneRaw: string;
  whatsapp: string;
  instagram: string;
  hours: RestaurantHours[];
}

export interface MenuItem {
  name: string;
  description: string;
  price: string;
}

export interface MenuCategory {
  id: string;
  roman: string;
  label: string;
  items: MenuItem[];
}

export interface Dish {
  id: string;
  name: string;
  description: string;
  price: string;
  category: string;
  image: string;
  label: string;
}

export interface Testimonial {
  id: string;
  name: string;
  rating: number;
  comment: string;
}

export interface GalleryImage {
  id: string;
  src: string;
  alt: string;
  label: string;
  tall?: boolean;
  wide?: boolean;
}

export interface NavLink {
  href: string;
  label: string;
}
