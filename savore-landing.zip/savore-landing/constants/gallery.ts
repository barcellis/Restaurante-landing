import type { GalleryImage } from "./types";
import { images } from "./images";

/**
 * SUBSTITUIR: fotos reais da galeria. `tall` e `wide` controlam o
 * grid tipo masonry em components/restaurant/Gallery.tsx.
 */
export const galleryImages: GalleryImage[] = [
  { id: "g1", src: images.gallery.g1, alt: "Salão do restaurante ao entardecer", label: "galeria-01.jpg", tall: true },
  { id: "g2", src: images.gallery.g2, alt: "Prato de massa fresca finalizado", label: "galeria-02.jpg" },
  { id: "g3", src: images.gallery.g3, alt: "Detalhe de talheres e guardanapo de linho", label: "galeria-03.jpg" },
  { id: "g4", src: images.gallery.g4, alt: "Chef finalizando prato na cozinha", label: "galeria-04.jpg", wide: true },
  { id: "g5", src: images.gallery.g5, alt: "Taça de vinho sobre mesa posta", label: "galeria-05.jpg" },
  { id: "g6", src: images.gallery.g6, alt: "Pessoas brindando à mesa", label: "galeria-06.jpg", tall: true },
  { id: "g7", src: images.gallery.g7, alt: "Sobremesa emplatada com detalhes finos", label: "galeria-07.jpg" },
  { id: "g8", src: images.gallery.g8, alt: "Fachada e entrada do restaurante à noite", label: "galeria-08.jpg" },
];
