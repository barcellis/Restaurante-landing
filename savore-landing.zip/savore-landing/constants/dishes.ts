import type { Dish } from "./types";
import { images } from "./images";

/**
 * SUBSTITUIR: pratos em destaque na seção "Uma seleção para despertar seus sentidos".
 */
export const featuredDishes: Dish[] = [
  { id: "d1", name: "Filé ao molho de vinho do Porto", description: "Filé mignon grelhado, redução de vinho do Porto e purê de mandioquinha.", price: "R$ 98", category: "Principal", image: images.dishes.dish01, label: "dish-01.jpg" },
  { id: "d2", name: "Risoto de cogumelos selvagens", description: "Arbóreo cremoso, mix de cogumelos, trufa negra e parmesão 24 meses.", price: "R$ 76", category: "Assinatura", image: images.dishes.dish02, label: "dish-02.jpg" },
  { id: "d3", name: "Tagliatelle ao ragù de 12 horas", description: "Massa fresca da casa com ragù de carnes lentamente cozido.", price: "R$ 68", category: "Massa", image: images.dishes.dish03, label: "dish-03.jpg" },
  { id: "d4", name: "Fondant de chocolate 70%", description: "Centro cremoso e sorvete de baunilha bourbon.", price: "R$ 34", category: "Sobremesa", image: images.dishes.dish04, label: "dish-04.jpg" },
];
