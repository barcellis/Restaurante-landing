import type { RestaurantInfo } from "./types";

/**
 * SUBSTITUIR: dados reais do restaurante.
 * Tudo que aparece no header, footer, seção de reserva e localização
 * vem exclusivamente deste arquivo.
 */
export const restaurant: RestaurantInfo = {
  name: "SAVORÉ",
  slogan: "Sabores que transformam momentos.",
  since: "2018",
  address: "Rua das Oliveiras, 245 — Jardins, São Paulo - SP",
  phone: "(11) 4002-8922",
  phoneRaw: "+551140028922",
  whatsapp: "5511999999999",
  instagram: "@savore.restaurante",
  hours: [
    { days: "Terça a Sexta", time: "18h às 23h30" },
    { days: "Sábado", time: "12h às 00h" },
    { days: "Domingo", time: "12h às 17h" },
    { days: "Segunda", time: "Fechado" },
  ],
};

export function whatsappLink(message: string): string {
  return `https://wa.me/${restaurant.whatsapp}?text=${encodeURIComponent(message)}`;
}
