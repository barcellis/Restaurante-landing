import type { MenuCategory } from "./types";

/**
 * SUBSTITUIR: cardápio completo real, com categorias, itens, descrições e preços.
 */
export const menuData: MenuCategory[] = [
  {
    id: "entradas",
    roman: "I",
    label: "Entradas",
    items: [
      { name: "Carpaccio de filé com alcaparras", description: "Fatias finas de filé mignon, azeite trufado, lascas de parmesão e rúcula selvagem.", price: "R$ 42" },
      { name: "Tartare de salmão defumado", description: "Salmão curado na casa, avocado, gergelim tostado e toast de brioche.", price: "R$ 48" },
      { name: "Burrata com tomates confit", description: "Burrata cremosa, tomates assados lentamente, manjericão e pesto.", price: "R$ 39" },
    ],
  },
  {
    id: "principais",
    roman: "II",
    label: "Principais",
    items: [
      { name: "Filé ao molho de vinho do Porto", description: "Filé mignon grelhado, redução de vinho do Porto, purê de mandioquinha.", price: "R$ 98" },
      { name: "Peixe branco em crosta de ervas", description: "Peixe do dia, crosta de ervas finas, legumes salteados e beurre blanc.", price: "R$ 89" },
      { name: "Risoto de cogumelos selvagens", description: "Arbóreo cremoso, mix de cogumelos, trufa negra e parmesão 24 meses.", price: "R$ 76" },
    ],
  },
  {
    id: "massas",
    roman: "III",
    label: "Massas",
    items: [
      { name: "Tagliatelle ao ragù de 12 horas", description: "Massa fresca da casa, ragù de carnes lentamente cozido, parmesão.", price: "R$ 68" },
      { name: "Ravioli de queijo e nozes", description: "Recheio artesanal, manteiga de sálvia e nozes tostadas.", price: "R$ 72" },
      { name: "Linguine aos frutos do mar", description: "Camarões, lula e mexilhões, molho leve de tomate e ervas frescas.", price: "R$ 84" },
    ],
  },
  {
    id: "carnes",
    roman: "IV",
    label: "Carnes",
    items: [
      { name: "Costela braseada 18 horas", description: "Costela bovina, redução própria, purê trufado.", price: "R$ 94" },
      { name: "Cordeiro ao alecrim", description: "Carré de cordeiro, crosta de ervas, molho de alecrim.", price: "R$ 108" },
      { name: "Picanha na brasa", description: "Corte nobre grelhado no ponto, farofa artesanal e vinagrete.", price: "R$ 89" },
    ],
  },
  {
    id: "sobremesas",
    roman: "V",
    label: "Sobremesas",
    items: [
      { name: "Fondant de chocolate 70%", description: "Centro cremoso, sorvete de baunilha bourbon.", price: "R$ 34" },
      { name: "Crème brûlée de baunilha", description: "Clássico francês, baunilha de Madagascar.", price: "R$ 32" },
      { name: "Tarte tatin de maçã", description: "Massa amanteigada, caramelo e chantilly.", price: "R$ 36" },
    ],
  },
  {
    id: "bebidas",
    roman: "VI",
    label: "Bebidas",
    items: [
      { name: "Seleção de vinhos", description: "Carta com rótulos nacionais e importados.", price: "Consulte" },
      { name: "Coquetéis autorais", description: "Criações exclusivas da casa.", price: "R$ 38" },
      { name: "Águas e refrigerantes", description: "Com e sem gás, opções artesanais.", price: "R$ 12" },
    ],
  },
];
