import type { NavLink } from "./types";

export const NAV_LINKS: NavLink[] = [
  { href: "#inicio", label: "Início" },
  { href: "#sobre", label: "Sobre" },
  { href: "#cardapio", label: "Cardápio" },
  { href: "#experiencia", label: "Experiência" },
  { href: "#galeria", label: "Galeria" },
  { href: "#contato", label: "Contato" },
];
