import type { Testimonial } from "./types";

/**
 * SUBSTITUIR: depoimentos reais de clientes.
 */
export const testimonials: Testimonial[] = [
  { id: "t1", name: "Marina Costa", rating: 5, comment: "Uma experiência completa, do atendimento à última colher da sobremesa. Já virou parada obrigatória." },
  { id: "t2", name: "Rafael Nunes", rating: 5, comment: "O risoto de cogumelos é de outro nível. Ambiente lindo, luz baixa, clima perfeito para uma noite especial." },
  { id: "t3", name: "Juliana Prado", rating: 4, comment: "Comida impecável e equipe muito atenciosa. Voltarei para experimentar o restante do cardápio." },
  { id: "t4", name: "Eduardo Lima", rating: 5, comment: "Reservei para comemorar um aniversário e superou todas as expectativas. Recomendo demais." },
];
