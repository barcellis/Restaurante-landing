Coloque aqui as fotos reais do restaurante, usando exatamente os nomes
listados em `constants/images.ts` (hero.jpg, story.jpg, dish-01.jpg,
ambiente-salao.jpg, galeria-01.jpg etc.). Enquanto um arquivo não existir,
o componente `components/restaurant/Photo.tsx` mostra automaticamente um
placeholder elegante no lugar dele — nenhum código precisa ser alterado.
