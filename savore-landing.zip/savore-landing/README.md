# SAVORÉ — Landing page (Next.js)

Projeto gerado a partir do prompt mestre da landing page do restaurante SAVORÉ.
Next.js (App Router) + TypeScript + Tailwind CSS.

## Como rodar

```bash
npm install
npm run dev
```

Abra http://localhost:3000

## Onde substituir o conteúdo real

| O que trocar | Onde |
|---|---|
| Nome, slogan, endereço, telefone, WhatsApp, Instagram, horários | `constants/restaurant.ts` |
| Cardápio completo | `constants/menu.ts` |
| Pratos em destaque | `constants/dishes.ts` |
| Depoimentos | `constants/testimonials.ts` |
| Fotos da galeria | `constants/gallery.ts` |
| Caminhos de imagem | `constants/images.ts` |
| Cores, tipografia e demais tokens visuais | `tailwind.config.ts` (cores `ink`, `paper`, `gold`) e `app/layout.tsx` (fontes) |
| Logo | trocar o texto "SAVORÉ" por `<Image>` em `Header.tsx` e `Footer.tsx` |

## Como adicionar as fotos reais

Coloque os arquivos dentro de `public/images/restaurant/` usando exatamente os
nomes já referenciados em `constants/images.ts` (`hero.jpg`, `dish-01.jpg`,
`galeria-01.jpg` etc.). Enquanto um arquivo não existir, o componente
`components/restaurant/Photo.tsx` mostra automaticamente um placeholder
elegante no lugar dele — não é necessário alterar nenhum código.

## Estrutura

```text
app/                     rotas (App Router), layout, metadata, globals.css
components/restaurant/   um componente por seção (Header, Hero, Gallery...)
constants/                dados separados da UI (restaurant, menu, dishes,
                           testimonials, gallery, images, nav)
hooks/                    useInView (scroll reveal) e useScrolled (header)
public/images/restaurant/ onde entram as fotos reais
```

## Próximos passos sugeridos

- Conectar o botão "Fazer reserva" a um sistema real de reservas
- Incorporar um Google Maps embed real na seção de localização
- Adicionar a imagem de Open Graph em `app/layout.tsx`
- Revisar o texto institucional em `components/restaurant/StorySection.tsx`
