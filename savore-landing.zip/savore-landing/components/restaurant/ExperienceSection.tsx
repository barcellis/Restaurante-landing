import { Reveal } from "./Reveal";
import { Photo } from "./Photo";
import { images } from "@/constants/images";

export function ExperienceSection() {
  return (
    <section id="experiencia" className="scroll-mt-24 bg-paper-alt">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-24 sm:py-32">
        <Reveal className="max-w-xl mb-14">
          <p className="text-gold-deep text-xs sm:text-sm tracking-widest uppercase mb-4">O ambiente</p>
          <h2 className="text-stone-900 text-4xl sm:text-5xl leading-tight font-display" style={{ fontWeight: 500 }}>
            O ambiente também faz parte da experiência.
          </h2>
        </Reveal>

        <div className="grid grid-cols-2 lg:grid-cols-12 gap-4 sm:gap-6">
          <Reveal className="col-span-2 lg:col-span-7">
            <Photo src={images.experience.salao} alt="Salão do restaurante com mesas postas e iluminação ambiente" label="ambiente-salao.jpg" className="w-full rounded-sm" style={{ aspectRatio: "16 / 10" }} sizes="(min-width: 1024px) 60vw, 100vw" />
          </Reveal>
          <Reveal className="lg:col-span-5" delay={80}>
            <Photo src={images.experience.detalhe} alt="Detalhe da decoração da mesa" label="ambiente-detalhe.jpg" className="w-full h-full rounded-sm" style={{ aspectRatio: "4 / 5" }} sizes="(min-width: 1024px) 40vw, 50vw" />
          </Reveal>
          <Reveal className="lg:col-span-5" delay={140}>
            <Photo src={images.experience.jantar} alt="Pessoas jantando em clima intimista" label="ambiente-pessoas.jpg" className="w-full rounded-sm" style={{ aspectRatio: "4 / 3" }} sizes="(min-width: 1024px) 40vw, 50vw" />
          </Reveal>
          <Reveal className="col-span-2 lg:col-span-7" delay={200}>
            <Photo src={images.experience.prato} alt="Prato sendo finalizado pelo chef" label="ambiente-prato.jpg" className="w-full rounded-sm" style={{ aspectRatio: "16 / 9" }} sizes="(min-width: 1024px) 60vw, 100vw" />
          </Reveal>
        </div>
      </div>
    </section>
  );
}
