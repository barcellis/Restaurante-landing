"use client";

import { useState, type CSSProperties } from "react";
import Image from "next/image";
import { UtensilsCrossed } from "lucide-react";

interface PhotoProps {
  src?: string;
  alt: string;
  label: string;
  className?: string;
  style?: CSSProperties;
  sizes?: string;
  priority?: boolean;
}

/**
 * Usa o caminho real de constants/images.ts quando o arquivo existir.
 * Caso o arquivo ainda não exista (fotos reais não entregues), cai
 * automaticamente num placeholder elegante — a página fica pronta
 * para apresentação mesmo antes das fotos finais chegarem.
 */
export function Photo({ src, alt, label, className = "", style, sizes = "100vw", priority = false }: PhotoProps) {
  const [failed, setFailed] = useState(false);
  const showPlaceholder = failed || !src;

  return (
    <div className={`relative overflow-hidden bg-ink-soft ${className}`} style={style}>
      {showPlaceholder ? (
        <div
          className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-stone-800 via-ink-soft to-ink"
          role="img"
          aria-label={alt}
        >
          <div className="flex flex-col items-center gap-3 px-6 text-center">
            <UtensilsCrossed className="w-7 h-7 text-gold" style={{ opacity: 0.7 }} strokeWidth={1.25} aria-hidden="true" />
            <span className="uppercase text-stone-400 font-body" style={{ fontSize: "11px", letterSpacing: "0.15em" }}>
              {label}
            </span>
          </div>
        </div>
      ) : (
        <Image
          src={src as string}
          alt={alt}
          fill
          sizes={sizes}
          priority={priority}
          onError={() => setFailed(true)}
          className="object-cover"
        />
      )}
    </div>
  );
}
