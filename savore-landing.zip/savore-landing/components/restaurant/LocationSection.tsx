import { Clock, Instagram, MapPin, Navigation, Phone } from "lucide-react";
import { Reveal } from "./Reveal";
import { restaurant } from "@/constants/restaurant";
import { buttonGhostLight } from "./ui";

export function LocationSection() {
  const mapsHref = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(restaurant.address)}`;

  return (
    <section id="contato" className="scroll-mt-24 bg-paper">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-24 sm:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <Reveal>
            <p className="text-gold-deep text-xs sm:text-sm tracking-widest uppercase mb-4">Localização</p>
            <h2 className="text-stone-900 text-4xl sm:text-5xl leading-tight mb-8 font-display" style={{ fontWeight: 500 }}>
              Venha nos visitar
            </h2>

            <dl className="space-y-5 text-stone-700 mb-8">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-gold-deep mt-0.5 shrink-0" aria-hidden="true" />
                <div><dt className="sr-only">Endereço</dt><dd>{restaurant.address}</dd></div>
              </div>
              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-gold-deep mt-0.5 shrink-0" aria-hidden="true" />
                <div>
                  <dt className="sr-only">Horário de funcionamento</dt>
                  <dd>
                    <ul>
                      {restaurant.hours.map((h) => (<li key={h.days}>{h.days}: {h.time}</li>))}
                    </ul>
                  </dd>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-gold-deep shrink-0" aria-hidden="true" />
                <div>
                  <dt className="sr-only">Telefone</dt>
                  <dd><a href={`tel:${restaurant.phoneRaw}`} className="hover:text-gold-deep focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold-deep">{restaurant.phone}</a></dd>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Instagram className="w-5 h-5 text-gold-deep shrink-0" aria-hidden="true" />
                <div>
                  <dt className="sr-only">Instagram</dt>
                  <dd>
                    <a href={`https://instagram.com/${restaurant.instagram.replace("@", "")}`} target="_blank" rel="noopener noreferrer" className="hover:text-gold-deep focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold-deep">
                      {restaurant.instagram}
                    </a>
                  </dd>
                </div>
              </div>
            </dl>

            <a href={mapsHref} target="_blank" rel="noopener noreferrer" className={buttonGhostLight}>
              Como chegar <Navigation className="w-4 h-4" aria-hidden="true" />
            </a>
          </Reveal>

          <Reveal delay={120}>
            {/* SUBSTITUIR: incorporar aqui um Google Maps embed real (iframe) apontando para o endereço final */}
            <div className="w-full rounded-sm border border-stone-200 flex items-center justify-center bg-paper-alt" style={{ aspectRatio: "4 / 3" }}>
              <div className="flex flex-col items-center gap-3 text-center px-6">
                <MapPin className="w-7 h-7 text-gold-deep" strokeWidth={1.25} aria-hidden="true" />
                <span className="text-stone-500 text-sm uppercase tracking-widest">Mapa — a ser incorporado</span>
                <span className="text-stone-400 text-xs">(ex.: Google Maps embed)</span>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
