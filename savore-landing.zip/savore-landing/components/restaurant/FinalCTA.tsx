import { Reveal } from "./Reveal";
import { Photo } from "./Photo";
import { images } from "@/constants/images";
import { buttonPrimary } from "./ui";

export function FinalCTA() {
  return (
    <section className="relative bg-ink">
      <Photo src={images.finalCta} alt="Composição de pratos e taças em mesa elegante" label="cta-final.jpg" className="absolute inset-0 w-full h-full" sizes="100vw" />
      <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(12,10,9,0.75) 0%, rgba(12,10,9,0.9) 100%)" }} aria-hidden="true" />
      <div className="relative max-w-3xl mx-auto px-6 sm:px-8 py-28 sm:py-32 text-center">
        <Reveal>
          <h2 className="text-stone-50 text-4xl sm:text-5xl leading-tight mb-8 font-display" style={{ fontWeight: 500 }}>
            Seu próximo momento especial começa aqui.
          </h2>
          <a href="#reserva" className={buttonPrimary}>Reservar uma mesa</a>
        </Reveal>
      </div>
    </section>
  );
}
