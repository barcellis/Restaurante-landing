import { Star } from "lucide-react";

interface StarRowProps {
  rating: number;
}

export function StarRow({ rating }: StarRowProps) {
  return (
    <div className="flex gap-1" role="img" aria-label={`Avaliação: ${rating} de 5 estrelas`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className="w-4 h-4"
          style={{ color: i < rating ? "#fbbf24" : "#44403c" }}
          fill={i < rating ? "#fbbf24" : "none"}
          aria-hidden="true"
        />
      ))}
    </div>
  );
}
