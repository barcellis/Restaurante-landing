"use client";

import { useState } from "react";
import { menuData } from "@/constants/menu";
import { restaurant, whatsappLink } from "@/constants/restaurant";
import { Reveal } from "./Reveal";
import { buttonOutline } from "./ui";

export function MenuSection() {
  const [active, setActive] = useState(menuData[0].id);
  const activeCategory = menuData.find((c) => c.id === active) ?? menuData[0];

  return (
    <section id="cardapio" className="scroll-mt-24 bg-ink">
      <div className="max-w-5xl mx-auto px-6 sm:px-8 lg:px-12 py-24 sm:py-32">
        <Reveal className="text-center max-w-xl mx-auto mb-12">
          <p className="text-gold text-xs sm:text-sm tracking-widest uppercase mb-4">Cardápio</p>
          <h2 className="text-stone-50 text-4xl sm:text-5xl leading-tight font-display" style={{ fontWeight: 500 }}>
            Uma jornada por categorias
          </h2>
        </Reveal>

        <div role="tablist" aria-label="Categorias do cardápio" className="flex flex-wrap justify-center gap-2 mb-12">
          {menuData.map((cat) => {
            const isActive = cat.id === active;
            return (
              <button
                key={cat.id}
                type="button"
                role="tab"
                id={`tab-${cat.id}`}
                aria-selected={isActive}
                aria-controls={`panel-${cat.id}`}
                onClick={() => setActive(cat.id)}
                className={`px-5 py-2.5 text-sm tracking-wide uppercase transition-colors rounded-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold ${
                  isActive ? "bg-gold text-ink" : "text-stone-300 hover:text-gold border border-stone-800"
                }`}
              >
                <span aria-hidden="true" className="mr-2">{cat.roman}</span>
                {cat.label}
              </button>
            );
          })}
        </div>

        <div role="tabpanel" id={`panel-${activeCategory.id}`} aria-labelledby={`tab-${activeCategory.id}`} className="grid sm:grid-cols-2 gap-x-10 gap-y-8">
          {activeCategory.items.map((item) => (
            <div key={item.name} className="flex items-start justify-between gap-4 pb-6 border-b border-stone-800">
              <div>
                <h3 className="text-stone-50 text-lg mb-1 font-display">{item.name}</h3>
                <p className="text-stone-400 text-sm leading-relaxed">{item.description}</p>
              </div>
              <span className="text-gold whitespace-nowrap pt-1">{item.price}</span>
            </div>
          ))}
        </div>

        <div className="text-center mt-14">
          <a href={whatsappLink(`Olá! Gostaria de receber o cardápio completo do ${restaurant.name}.`)} target="_blank" rel="noopener noreferrer" className={buttonOutline}>
            Ver cardápio completo
          </a>
        </div>
      </div>
    </section>
  );
}
