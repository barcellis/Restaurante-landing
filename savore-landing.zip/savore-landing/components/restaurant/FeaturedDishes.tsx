import { Reveal } from "./Reveal";
import { Photo } from "./Photo";
import { featuredDishes } from "@/constants/dishes";

export function FeaturedDishes() {
  return (
    <section className="bg-ink">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-24 sm:py-32">
        <Reveal className="max-w-xl mb-14">
          <p className="text-gold text-xs sm:text-sm tracking-widest uppercase mb-4">Cardápio em destaque</p>
          <h2 className="text-stone-50 text-4xl sm:text-5xl leading-tight font-display" style={{ fontWeight: 500 }}>
            Uma seleção para despertar seus sentidos
          </h2>
        </Reveal>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredDishes.map((dish, i) => (
            <Reveal key={dish.id} delay={i * 90}>
              <article className="group">
                <div className="relative overflow-hidden rounded-sm mb-4" style={{ aspectRatio: "3 / 4" }}>
                  <Photo
                    src={dish.image}
                    alt={dish.name}
                    label={dish.label}
                    className="w-full h-full transition-transform duration-700 group-hover:scale-105"
                    sizes="(min-width: 1024px) 25vw, 50vw"
                  />
                  <div
                    className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    aria-hidden="true"
                  />
                  <span
                    className="absolute top-4 left-4 text-xs tracking-widest uppercase text-stone-100 px-3 py-1 rounded-sm"
                    style={{ backgroundColor: "rgba(12,10,9,0.6)", backdropFilter: "blur(4px)" }}
                  >
                    {dish.category}
                  </span>
                </div>
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-stone-50 text-lg font-display">{dish.name}</h3>
                  <span className="text-gold text-sm whitespace-nowrap pt-1">{dish.price}</span>
                </div>
                <p className="text-stone-400 text-sm mt-2 leading-relaxed">{dish.description}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
