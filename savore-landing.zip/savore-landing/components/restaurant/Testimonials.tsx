import { Reveal } from "./Reveal";
import { StarRow } from "./StarRow";
import { testimonials } from "@/constants/testimonials";

export function Testimonials() {
  return (
    <section className="bg-stone-900">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-24 sm:py-32">
        <Reveal className="max-w-xl mb-14">
          <p className="text-gold text-xs sm:text-sm tracking-widest uppercase mb-4">Depoimentos</p>
          <h2 className="text-stone-50 text-4xl sm:text-5xl leading-tight font-display" style={{ fontWeight: 500 }}>
            Experiências que ficam na memória
          </h2>
        </Reveal>

        <div className="flex sm:grid sm:grid-cols-2 lg:grid-cols-4 gap-6 overflow-x-auto snap-x snap-mandatory sm:overflow-visible pb-4 sm:pb-0">
          {testimonials.map((t, i) => (
            <Reveal key={t.id} delay={i * 90} className="shrink-0 w-5/6 sm:w-auto">
              <div className="snap-center h-full bg-ink border border-stone-800 rounded-sm p-7">
                <StarRow rating={t.rating} />
                <p className="text-stone-300 leading-relaxed mt-4 mb-6">&ldquo;{t.comment}&rdquo;</p>
                <p className="text-stone-100 text-sm tracking-wide font-display">{t.name}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
