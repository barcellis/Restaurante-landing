import { restaurant } from "@/constants/restaurant";
import { NAV_LINKS } from "@/constants/nav";

export function Footer() {
  return (
    <footer className="bg-ink border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          <div>
            {/* SUBSTITUIR: trocar por <Image> do logo real quando disponível */}
            <p className="text-2xl tracking-widest uppercase text-stone-50 mb-4 font-display">{restaurant.name}</p>
            <p className="text-stone-400 text-sm leading-relaxed">{restaurant.slogan}</p>
          </div>
          <div>
            <p className="text-stone-200 text-sm uppercase tracking-widest mb-4">Navegação</p>
            <ul className="space-y-2 text-stone-400 text-sm">
              {NAV_LINKS.map((l) => (
                <li key={l.href}><a href={l.href} className="hover:text-gold focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold">{l.label}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-stone-200 text-sm uppercase tracking-widest mb-4">Contato</p>
            <ul className="space-y-2 text-stone-400 text-sm">
              <li>{restaurant.address}</li>
              <li><a href={`tel:${restaurant.phoneRaw}`} className="hover:text-gold focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold">{restaurant.phone}</a></li>
              <li><a href={`https://instagram.com/${restaurant.instagram.replace("@", "")}`} target="_blank" rel="noopener noreferrer" className="hover:text-gold focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold">{restaurant.instagram}</a></li>
            </ul>
          </div>
          <div>
            <p className="text-stone-200 text-sm uppercase tracking-widest mb-4">Horário</p>
            <ul className="space-y-2 text-stone-400 text-sm">
              {restaurant.hours.map((h) => (<li key={h.days}>{h.days}: {h.time}</li>))}
            </ul>
          </div>
        </div>
        <div className="pt-8 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-stone-500 text-xs">
          <span>© {new Date().getFullYear()} {restaurant.name}. Todos os direitos reservados.</span>
          <span>Landing page demo — conteúdo e imagens provisórios</span>
        </div>
      </div>
    </footer>
  );
}
