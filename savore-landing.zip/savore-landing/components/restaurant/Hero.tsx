import { Clock, MapPin } from "lucide-react";
import { Photo } from "./Photo";
import { images } from "@/constants/images";
import { buttonPrimary, buttonOutline } from "./ui";

export function Hero() {
  return (
    <section id="inicio" className="relative min-h-screen flex items-end scroll-mt-24 overflow-hidden bg-ink">
      <Photo
        src={images.hero}
        alt="Prato principal do SAVORÉ em composição elegante, servido em ambiente de luz baixa"
        label="hero.jpg — 1600×1000"
        className="absolute inset-0 w-full h-full"
        priority
        sizes="100vw"
      />
      <div
        className="absolute inset-0"
        style={{ background: "linear-gradient(180deg, rgba(12,10,9,0.55) 0%, rgba(12,10,9,0.35) 35%, rgba(12,10,9,0.92) 100%)" }}
        aria-hidden="true"
      />

      <div className="relative max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 pb-20 sm:pb-24 w-full">
        <div className="max-w-2xl">
          <p className="savore-hero-item text-gold text-xs sm:text-sm tracking-widest uppercase mb-5 font-body" style={{ animationDelay: "0.1s" }}>
            Uma experiência à mesa
          </p>
          <h1 className="savore-hero-item text-stone-50 text-5xl sm:text-6xl lg:text-7xl leading-tight mb-6 font-display" style={{ fontWeight: 500, animationDelay: "0.25s" }}>
            Sabores que transformam momentos.
          </h1>
          <p className="savore-hero-item text-stone-300 text-base sm:text-lg leading-relaxed max-w-xl mb-10" style={{ animationDelay: "0.4s" }}>
            Uma experiência gastronômica criada para quem aprecia ingredientes especiais, sabores marcantes e momentos inesquecíveis.
          </p>
          <div className="savore-hero-item flex flex-wrap gap-4" style={{ animationDelay: "0.55s" }}>
            <a href="#reserva" className={buttonPrimary}>Reservar uma mesa</a>
            <a href="#cardapio" className={buttonOutline}>Conhecer o cardápio</a>
          </div>
        </div>

        <div className="savore-hero-item mt-16 flex flex-wrap items-center gap-x-10 gap-y-4 text-stone-300 text-sm" style={{ animationDelay: "0.7s" }}>
          <span className="inline-flex items-center gap-2"><Clock className="w-4 h-4 text-gold" aria-hidden="true" />Ter–Dom, a partir das 12h</span>
          <span className="inline-flex items-center gap-2"><MapPin className="w-4 h-4 text-gold" aria-hidden="true" />Jardins, São Paulo</span>
        </div>
      </div>

      <a
        href="#sobre"
        className="hidden sm:flex absolute bottom-8 right-8 flex-col items-center gap-2 text-stone-300 text-xs tracking-widest uppercase focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold"
        aria-label="Rolar para a próxima seção"
      >
        <span className="savore-scroll-indicator w-px h-12 bg-stone-400" aria-hidden="true" />
        Rolar
      </a>
    </section>
  );
}
