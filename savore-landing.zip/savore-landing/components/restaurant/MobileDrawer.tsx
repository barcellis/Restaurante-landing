"use client";

import type { RefObject } from "react";
import { X } from "lucide-react";
import { restaurant } from "@/constants/restaurant";
import { NAV_LINKS } from "@/constants/nav";
import { buttonPrimary } from "./ui";

interface MobileDrawerProps {
  open: boolean;
  onClose: () => void;
  firstLinkRef: RefObject<HTMLAnchorElement>;
}

export function MobileDrawer({ open, onClose, firstLinkRef }: MobileDrawerProps) {
  return (
    <div
      id="mobile-drawer"
      className={`lg:hidden fixed inset-0 z-40 transition-opacity duration-300 ${open ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0"}`}
      role="dialog"
      aria-modal="true"
      aria-hidden={!open}
      aria-label="Menu de navegação"
    >
      <div className="absolute inset-0 bg-ink" style={{ opacity: open ? 0.7 : 0 }} onClick={onClose} />
      <div
        className={`absolute top-0 right-0 h-full w-5/6 max-w-sm bg-ink border-l border-stone-800 flex flex-col transition-transform duration-300 ${open ? "translate-x-0" : "translate-x-full"}`}
      >
        <div className="flex items-center justify-between h-20 px-6 border-b border-stone-800">
          <span className="text-lg tracking-widest uppercase text-stone-50 font-display">{restaurant.name}</span>
          <button
            type="button"
            onClick={onClose}
            className="w-11 h-11 inline-flex items-center justify-center text-stone-200 focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold"
            aria-label="Fechar menu"
          >
            <X className="w-6 h-6" aria-hidden="true" />
          </button>
        </div>
        <nav className="flex-1 flex flex-col justify-center gap-2 px-8" aria-label="Navegação móvel">
          {NAV_LINKS.map((link, i) => (
            <a
              key={link.href}
              href={link.href}
              ref={i === 0 ? firstLinkRef : undefined}
              tabIndex={open ? 0 : -1}
              onClick={onClose}
              className="py-3 text-2xl text-stone-100 hover:text-gold focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold transition-colors font-display"
            >
              {link.label}
            </a>
          ))}
        </nav>
        <div className="p-8 border-t border-stone-800">
          <a href="#reserva" tabIndex={open ? 0 : -1} onClick={onClose} className={`${buttonPrimary} w-full justify-center`}>
            Reservar mesa
          </a>
        </div>
      </div>
    </div>
  );
}
