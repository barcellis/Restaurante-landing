"use client";

import { useEffect, useRef, useState } from "react";
import { Menu } from "lucide-react";
import { useScrolled } from "@/hooks/useScrolled";
import { restaurant } from "@/constants/restaurant";
import { NAV_LINKS } from "@/constants/nav";
import { buttonPrimary } from "./ui";
import { MobileDrawer } from "./MobileDrawer";

export function Header() {
  const scrolled = useScrolled(60);
  const [open, setOpen] = useState(false);
  const menuBtnRef = useRef<HTMLButtonElement>(null);
  const firstLinkRef = useRef<HTMLAnchorElement>(null);

  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
      firstLinkRef.current?.focus();
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape" && open) {
        setOpen(false);
        menuBtnRef.current?.focus();
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open]);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-40 transition-colors duration-500 ${scrolled ? "backdrop-blur-md" : ""}`}
      style={{ backgroundColor: scrolled ? "rgba(12,10,9,0.88)" : "transparent" }}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        <div className="flex items-center justify-between h-20">
          {/* SUBSTITUIR: trocar o texto abaixo por <Image src={...} alt="Logo SAVORÉ" /> quando houver identidade visual */}
          <a
            href="#inicio"
            className="text-2xl tracking-widest uppercase text-stone-50 font-display focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold focus-visible:outline-offset-4"
          >
            {restaurant.name}
          </a>

          <nav className="hidden lg:flex items-center gap-10" aria-label="Navegação principal">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm tracking-wide uppercase text-stone-200 hover:text-gold focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold focus-visible:outline-offset-4 transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="hidden lg:block">
            <a href="#reserva" className={buttonPrimary}>Reservar mesa</a>
          </div>

          <button
            ref={menuBtnRef}
            type="button"
            onClick={() => setOpen(true)}
            className="lg:hidden inline-flex items-center justify-center w-11 h-11 text-stone-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold"
            aria-label="Abrir menu"
            aria-expanded={open}
            aria-controls="mobile-drawer"
          >
            <Menu className="w-6 h-6" aria-hidden="true" />
          </button>
        </div>
      </div>

      <MobileDrawer
        open={open}
        onClose={() => {
          setOpen(false);
          menuBtnRef.current?.focus();
        }}
        firstLinkRef={firstLinkRef}
      />
    </header>
  );
}
