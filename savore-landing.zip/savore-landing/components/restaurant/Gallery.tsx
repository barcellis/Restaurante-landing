"use client";

import { useState } from "react";
import { Reveal } from "./Reveal";
import { Photo } from "./Photo";
import { Lightbox } from "./Lightbox";
import { galleryImages } from "@/constants/gallery";
import { restaurant } from "@/constants/restaurant";

export function Gallery() {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  return (
    <section id="galeria" className="scroll-mt-24 bg-paper">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-24 sm:py-32">
        <Reveal className="max-w-xl mb-14">
          <p className="text-gold-deep text-xs sm:text-sm tracking-widest uppercase mb-4">Galeria</p>
          <h2 className="text-stone-900 text-4xl sm:text-5xl leading-tight font-display" style={{ fontWeight: 500 }}>
            Um convite visual à experiência {restaurant.name}
          </h2>
        </Reveal>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4" style={{ gridAutoRows: "160px" }}>
          {galleryImages.map((img, i) => (
            <Reveal key={img.id} delay={(i % 4) * 70} className={`${img.tall ? "row-span-2" : "row-span-1"} ${img.wide ? "col-span-2" : "col-span-1"}`}>
              <button type="button" onClick={() => setLightboxIndex(i)} className="relative w-full h-full overflow-hidden rounded-sm group focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold-deep" aria-label={`Ampliar imagem: ${img.alt}`}>
                <Photo src={img.src} alt={img.alt} label={img.label} className="w-full h-full transition-transform duration-700 group-hover:scale-105" sizes="(min-width: 640px) 25vw, 50vw" />
              </button>
            </Reveal>
          ))}
        </div>
      </div>

      {lightboxIndex !== null && (
        <Lightbox images={galleryImages} index={lightboxIndex} onClose={() => setLightboxIndex(null)} onNavigate={setLightboxIndex} />
      )}
    </section>
  );
}
