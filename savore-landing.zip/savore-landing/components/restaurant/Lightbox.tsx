"use client";

import { useEffect, useRef } from "react";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { Photo } from "./Photo";
import type { GalleryImage } from "@/constants/types";

interface LightboxProps {
  images: GalleryImage[];
  index: number;
  onClose: () => void;
  onNavigate: (index: number) => void;
}

export function Lightbox({ images, index, onClose, onNavigate }: LightboxProps) {
  const closeBtnRef = useRef<HTMLButtonElement>(null);
  const current = images[index];

  useEffect(() => {
    document.body.style.overflow = "hidden";
    closeBtnRef.current?.focus();
    return () => {
      document.body.style.overflow = "";
    };
  }, []);

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") onNavigate((index + 1) % images.length);
      if (e.key === "ArrowLeft") onNavigate((index - 1 + images.length) % images.length);
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [index, images.length, onClose, onNavigate]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4" role="dialog" aria-modal="true" aria-label={`Imagem ${index + 1} de ${images.length}: ${current.alt}`}>
      <div className="absolute inset-0 bg-ink" style={{ opacity: 0.95 }} onClick={onClose} aria-hidden="true" />

      <div className="relative w-full max-w-4xl">
        <button ref={closeBtnRef} type="button" onClick={onClose} className="absolute -top-12 right-0 w-11 h-11 inline-flex items-center justify-center text-stone-200 hover:text-gold focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold" aria-label="Fechar galeria">
          <X className="w-6 h-6" aria-hidden="true" />
        </button>

        <Photo src={current.src} alt={current.alt} label={current.label} className="w-full rounded-sm" style={{ aspectRatio: "16 / 10" }} sizes="(min-width: 1024px) 60vw, 100vw" />

        <div className="flex items-center justify-between mt-4">
          <button type="button" onClick={() => onNavigate((index - 1 + images.length) % images.length)} className="inline-flex items-center gap-2 text-stone-300 hover:text-gold text-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold" aria-label="Imagem anterior">
            <ChevronLeft className="w-5 h-5" aria-hidden="true" /> Anterior
          </button>
          <span className="text-stone-500 text-sm">{index + 1} / {images.length}</span>
          <button type="button" onClick={() => onNavigate((index + 1) % images.length)} className="inline-flex items-center gap-2 text-stone-300 hover:text-gold text-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold" aria-label="Próxima imagem">
            Próxima <ChevronRight className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>
      </div>
    </div>
  );
}
