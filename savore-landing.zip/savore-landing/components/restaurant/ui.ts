/**
 * Classes de botão reutilizadas em toda a landing page.
 * Centralizado aqui para não repetir/espalhar estilos pelo código.
 */
export const buttonPrimary =
  "inline-flex items-center gap-2 bg-gold text-ink hover:bg-gold-soft transition-colors px-7 py-3.5 text-sm tracking-wide uppercase font-medium rounded-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-soft";

export const buttonOutline =
  "inline-flex items-center gap-2 border border-stone-400 text-stone-100 hover:border-gold hover:text-gold transition-colors px-7 py-3.5 text-sm tracking-wide uppercase font-medium rounded-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold";

export const buttonGhostLight =
  "inline-flex items-center gap-2 text-stone-900 hover:text-gold-deep text-sm tracking-wide uppercase border-b border-stone-900 hover:border-gold-deep pb-1 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-deep";
