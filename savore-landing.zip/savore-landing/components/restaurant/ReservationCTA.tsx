import { MessageCircle } from "lucide-react";
import { Reveal } from "./Reveal";
import { Photo } from "./Photo";
import { restaurant, whatsappLink } from "@/constants/restaurant";
import { images } from "@/constants/images";
import { buttonPrimary, buttonOutline } from "./ui";

export function ReservationCTA() {
  return (
    <section id="reserva" className="relative scroll-mt-24 bg-ink">
      <Photo src={images.reservation} alt="Mesa reservada com talheres dispostos, pronta para receber convidados" label="reserva-bg.jpg" className="absolute inset-0 w-full h-full" sizes="100vw" />
      <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(12,10,9,0.85) 0%, rgba(12,10,9,0.92) 100%)" }} aria-hidden="true" />

      <div className="relative max-w-3xl mx-auto px-6 sm:px-8 py-28 sm:py-36 text-center">
        <Reveal>
          <p className="text-gold text-xs sm:text-sm tracking-widest uppercase mb-5">Reservas</p>
          <h2 className="text-stone-50 text-4xl sm:text-5xl leading-tight mb-6 font-display" style={{ fontWeight: 500 }}>
            Sua mesa está esperando por você.
          </h2>
          <p className="text-stone-300 leading-relaxed mb-10 max-w-xl mx-auto">
            Reserve seu momento e venha viver uma experiência gastronômica especial.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a href={whatsappLink(`Olá! Gostaria de reservar uma mesa no ${restaurant.name}.`)} target="_blank" rel="noopener noreferrer" className={buttonPrimary}>
              <MessageCircle className="w-4 h-4" aria-hidden="true" /> Reservar pelo WhatsApp
            </a>
            {/* SUBSTITUIR: conectar a um sistema real de reservas (ex.: OpenTable, Sympla, API própria) */}
            <a href="#contato" className={buttonOutline}>Fazer reserva</a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
