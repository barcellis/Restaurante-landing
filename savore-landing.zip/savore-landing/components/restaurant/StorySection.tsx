import { ArrowRight } from "lucide-react";
import { Reveal } from "./Reveal";
import { Photo } from "./Photo";
import { restaurant } from "@/constants/restaurant";
import { images } from "@/constants/images";
import { buttonGhostLight } from "./ui";

export function StorySection() {
  return (
    <section id="sobre" className="scroll-mt-24 bg-paper">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-24 sm:py-32">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          <Reveal className="lg:col-span-7 lg:order-2">
            <Photo
              src={images.story}
              alt="Interior aconchegante do SAVORÉ, com mesas postas e iluminação baixa"
              label="story.jpg — 1200×1500"
              className="w-full rounded-sm shadow-2xl"
              style={{ aspectRatio: "4 / 5" }}
              sizes="(min-width: 1024px) 55vw, 100vw"
            />
          </Reveal>

          <Reveal className="lg:col-span-5 lg:order-1" delay={120}>
            <p className="text-gold-deep text-xs sm:text-sm tracking-widest uppercase mb-4">Nossa história</p>
            <h2 className="text-stone-900 text-4xl sm:text-5xl leading-tight mb-6 font-display" style={{ fontWeight: 500 }}>
              Mais do que uma refeição. Uma experiência.
            </h2>
            {/* SUBSTITUIR: texto institucional real do restaurante */}
            <p className="text-stone-600 leading-relaxed mb-4">
              O {restaurant.name} nasceu do desejo de transformar cada visita em uma lembrança. Cada prato é pensado
              como parte de uma narrativa maior, onde técnica, ingredientes sazonais e hospitalidade se encontram à mesa.
            </p>
            <p className="text-stone-600 leading-relaxed mb-8">
              Da cozinha à sala, cada detalhe é cuidado para que o tempo passe devagar — e o momento fique.
            </p>
            <div className="flex flex-wrap gap-x-3 gap-y-2 mb-8 text-sm text-stone-500">
              <span>Desde {restaurant.since}</span>
              <span aria-hidden="true">•</span>
              <span>Ingredientes selecionados</span>
              <span aria-hidden="true">•</span>
              <span>Experiência gastronômica</span>
            </div>
            <a href="#experiencia" className={buttonGhostLight}>
              Conheça nossa história <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </a>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
